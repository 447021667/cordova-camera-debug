# cordova概述

## 什么是 cordova

- 一个移动应用开发框架
- 本质是在 html, css, js 外面包装个原生的壳
- 出自于 Adobe 11年收购的 PhoneGap,  是 驱动PhoneGap 的核心引擎
- 是 apache 的顶级开源项目


Cordova提供了一系列设备相关的API，通过这组API，移动应用能够以JavaScript访问原生的设备功能，如摄像头、麦克风等。



## 常见的移动端开发的三大分类

1. 原生 App

2. web App

3. 混合 App  (Hybrid App)

   ​


## cordova 的优缺点

优点:   **跨平台**, 便于移植,  开发快速, **成本低**

缺点:   执行速度相对原生会慢一些,   一次编写, 要处处调试



## cordova 的架构

<img src="./img/cordovaapparchitecture.png">

- **Web APP** :  存放应用程序代码的地方,  体现是你的具体业务逻辑模块

- **WebView **:  给应用提供完整的用户访问呈现

- **Cordova Plugins**:  提供了和原生组件通信的接口并绑定到了标准的设备API,  将来通过 js 来调用

  ​

## cordova 在整个 App 领域的位置

<img src="./img/地位.png">

cordova 官网:   https://cordova.apache.org/





# cordova 环境安装

1. **git 的安装**

   git 下载地址:  https://git-scm.com/downloads

   Cordova安装要使用 git 命令完成一些后台进程。

   查看版本: ` git  --version`

   ​

2. **nodejs 的安装**

   nodejs官网:   http://nodejs.cn/

   查看版本: `node -v `

   ​

3. **安装Cordova CLI**,   下载并安装Cordova全局模块

   安装:  `npm  install  -g  cordova`

   查看版本: `cordova -v `

   ​

4. **安装Java  JDK**       

   下载地址: https://www.oracle.com/technetwork/java/javase/downloads/index.html

   查看版本:  `java  -version`

   ​		  `javac  -version`

   有关JDK的安装，请参考：<http://www.yiibai.com/java/java_environment_setup.html>

   ​

5. **安装 android studio,  安装 Andorid SDK,   **

   官网地址: http://www.android-studio.org/

   有关android studio 安装, 请参考: https://www.yiibai.com/android/android_environment_setup.html



# cordova的第一个应用

**使用 cordova 创建 Hello World 项目**

**执行命令:**

1. `cordova  create  hello  com.example.hello  helloWorld`     创建项目

2. `cd  hello`   切换目录

3. `cordova  platform  add  android`    添加 andorid 平台,  加入 android 运行时

4. `cordova  build`  编译运行

5. `cordova run android`   在设备上运行

   教程: android studio 模拟器使用入门: https://blog.csdn.net/qq_41916089/article/details/81044989

   ​

**目录文件介绍:**

- config.xml 配置页,  配置起始页项目名称等基础内容

- hooks 存放一些自定义扩展功能

- platforms  存放添加的platform运行时

- plugins  存放引入的插件

- www  开发的 html5 目录

  ​


## cordova 插件和事件说明

cordova对于设备功能的封装, 都是以事件或者插件体现的

插件即plugin, 他封装了设备能提供的功能, 如: 摄像头, 通讯录,  gps 等, 他们是以自定义的 js 根对象 或者 覆盖标准对象的方式提供的, 插件需要单独安装才能使用



# cordova 事件

## cordova 事件概览

| 事件名称            | 说明                    |
| --------------- | --------------------- |
| **deviceready** | 当Cordova 加载完成后该事件被触发。 |
| **pause**       | 当应用程序被置于后台，则触发此事件。    |
| **resume**      | 当应用程序从后台返回，则触发此事件。    |
| **backbutton**  | 当按下后退按钮时，则触发此事件。      |
| ......          | ......                |



## cordova 事件的使用

所有的事件调用方式类似,  通过 js 进行事件监听即可 ( addEventListener )

```js
document.addEventListener("deviceready", onDeviceReady);

function onDeviceReady() {
    // Now safe to use device APIs
}
```



## cordova 应用启动流程

html页面加载流程

1. 原生代码启动
2. splashscreen
3. load html
4. 顺序执行 javascript   =>  cordova.js 也执行
5. $(document).ready()  执行,  cordova 中的事件不一定可用
6. 注册 deviceready 事件


# cordova 手机电池状态

这个 Cordova 插件用于监视设备的电池状态。

1. 安装电池插件

   ```
   cordova plugin add cordova-plugin-battery-status
   ```

2. 添加事件监听

   **事件监听必须在 `deviceready`  调用完成后调用, 且必须通过 window 添加监听**

   ```js
   window.addEventListener("batterystatus", onBatteryStatus, false);
   ```

3. 回调函数

   ```js
   function onBatteryStatus(status) {
      console.log("电池状态:  Level: " + status.level + " isPlugged: " + status.isPlugged);
   }
   ```

每个事件都会返回一个 status 对象,   有两个属性

- **level**: 当前电量的百分比值, 范围 (0-100)   number数值类型
- **isPlugged**:  标记当前手机是否在充电        boolean类型

三个事件

| 事件名称            | 事件说明                                    |
| --------------- | --------------------------------------- |
| batterystatus   | 当电池发生1%的变化时触发,  或者充电状态发生切换时触发           |
| batterylow      | 当电池电量百分比达到了较低的值时，则触发此事件。此值在不同的设备可能有所不同。 |
| batterycritical | 当电池电量百分比达到临界值时，则触发此事件。此值在不同的设备可能有所不同。   |





# cordova 照相机

这个插件定义了一个全局的 `navigator.camera` 对象,  这个对象提供了用于拍照或者使用图库文件的 api

这个对象, 只在 `deviceready` 事件触发后, 才存在

## 手机拍照显示

1. 安装照相机插件

   ```
   cordova plugin add cordova-plugin-camera
   ```

2. 添加事件监听

   ```js
   document.querySelector('#takePic').addEventListener('click', takePicure);
   ```

3. 添加功能

   ```js
   // 拍照功能
   function takePicure() {
     // 调用插件api提供的 navigator.camera 全局对象
     navigator.camera.getPicture( onSuccess, onFail, {
       quality: 50,
       destinationType: Camera.DestinationType.DATA_URL
     });

     function onSuccess(imageData) {
       var img = document.querySelector("img");
       img.src = "data:image/jpeg;base64," + imageData;
     }

     function onFail(message) {
       console.log( "failed because " + message );
     }
   }
   ```



## 手册相册读取图片

1. 安装照相机插件

   ```
   cordova plugin add cordova-plugin-camera
   ```

2. 添加点击监听

   ```js
   document.querySelector('#selectPic').addEventListener('click', selectPicure);
   ```

3. 添加功能

   ```js
     // 选择照片功能
     function selectPicure() {
        navigator.camera.getPicture(onSuccess, onFail, { 
          quality: 50,
          destinationType: Camera.DestinationType.NATIVE_URI,
          sourceType: Camera.PictureSourceType.PHOTOLIBRARY
        });

        function onSuccess(imageURL) {
          var img = document.querySelector("img");
          img.src = imageURL;
        }

        function onFail(message) {
          console.log('Failed because: ' + message);
        }
     }
   ```




| 参数名                 | 配置值                          |
| ------------------- | ---------------------------- |
| **quality**         | 在0-100的范围内的图像质量。默认值是50。      |
| **destinationType** | DATA_URL 或 0 返回base64编码字符串   |
|                     | FILE_URI 或 1 返回图像文件URI       |
|                     | NATIVE_URI 或 2 返回图像本地URI     |
| **sourceType**      | PHOTOLIBRARY 或 0 打开照片库       |
|                     | CAMERA 或 1打开机摄像头             |
|                     | SAVEDPHOTOALBUM 或 2 打开保存相册   |
| **allowEdit**       | 允许图像编辑                       |
| **encodingType**    | **JPEG** 或 **0** 返回JPEG编码的图像 |
|                     | **PNG** 或 **1** 返回PNG编码的图像   |
| **targetWidth**     | 图像中的像素缩放宽度                   |
| **targetHeight**    | 图像中的像素比例的高度                  |
| **cameraDirection** | **FRONT** 或 **0** 前置摄像头      |
|                     | **BACK** 或 **1** 后置摄像头       |





# cordova 振动

这个插件是用于实现振动功能。

1. 安装振动插件

   ```
   cordova plugin add cordova-plugin-vibration
   ```

2. 添加点击监听

   ```
   // 这里添加一些监听
   document.querySelector('#btn1').addEventListener("click", vibration);
   document.querySelector('#btn2').addEventListener("click", vibrationPattern);
   ```

3. 添加功能

   ```js
   function vibration() {
     // 第一个函数使用 time 参数, 用于设置连续振动的持续时间
     var time = 3000;   // 振动 3 秒
     navigator.vibrate( time );
   }

   function vibrationPattern() {
     var pattern = [1000, 1000, 1000, 1000];
     navigator.vibrate(pattern);
   }
   ```



# cordova 多媒体播放

1. 安装插件

   ```
   cordova plugin add cordova-plugin-media
   ```

2. 准备按钮

   ```
   <button id = "playAudio">播放音频</button>
   <button id = "pauseAudio">暂停音频</button>
   <button id = "stopAudio">停止音频</button>
   <button id = "volumeUp">增大音量</button>
   <button id = "volumeDown">减小音量</button>
   ```

3. 添加事件监听

   ```
   document.getElementById("playAudio").addEventListener("click", playAudio);
   document.getElementById("pauseAudio").addEventListener("click", pauseAudio);
   document.getElementById("stopAudio").addEventListener("click", stopAudio);
   document.getElementById("volumeUp").addEventListener("click", volumeUp);
   document.getElementById("volumeDown").addEventListener("click", volumeDown);
   ```

4. 添加功能

   - 播放功能

     ```js
     // 播放音频
     function playAudio() {
       var src = "/android_asset/www/video/bg.mp3"; // 指定音频的路径

       if ( myMedia === null ) {
         myMedia = new Media( src, onSuccess, onError );
         function onSuccess() {
           console.log("playAudio Success");
         }
         function onError(error) {
           console.log("playAudio Error: " + error.code);
         }
       }
       console.log("播放音乐");
       // 播放音频
       myMedia.play();
     }
     ```

   - 暂停功能

     ```js
     // 暂停音频
     function pauseAudio() {
       if ( myMedia ) {
         console.log("暂停音乐");
         myMedia.pause();
       }
     }
     ```

   - 停止功能

     ```js
     // 停止音频
     function stopAudio() {
       if ( myMedia ) {
         myMedia.stop();
       }
       console.log("停止音频");
       myMedia = null;
     }
     ```

   - 控制音量

     ```js
     // 音量函数功能
     var volumeValue = 0.5;
     function volumeUp() {
       if ( myMedia && volumeValue < 1 ) {
         myMedia.setVolume( volumeValue += 0.1 );
       }
       console.log( "当前音量:" + volumeValue );
     }
     function volumeDown() {
       if(myMedia && volumeValue > 0) {
          myMedia.setVolume(volumeValue -= 0.1);
       }
       console.log( "当前音量:" + volumeValue );
     } 
     ```

插件提供的方法表:

| 方法                 | 说明            |
| ------------------ | ------------- |
| getCurrentPosition | 返回音频的当前位置     |
| getDuration        | 返回一个音频的持续时间   |
| play               | 用于开始或恢复音频     |
| pause              | 用于暂停音频        |
| release            | 发布底层操作系统的音频资源 |
| seekTo             | 用于改变音频的位置     |
| setVolume          | 用于音频设置音量      |
| startRecord        | 开始录制音频文件      |
| stopRecord         | 停止录制音频文件      |
| stop               | 停止播放音频文件      |

